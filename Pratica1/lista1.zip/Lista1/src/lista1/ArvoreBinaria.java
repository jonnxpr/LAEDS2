package lista1;

/*
 *
 * @author Jonathan Douglas Diego Tavares
 * @matricula 201622040228
 * @disciplina Laboratório de Algoritmos e Estrutura de Dados II
 * 
 */

/**
 * Classe ArvoreBinaria
 * Função: Classe responsável por representar a estrutura de uma arvore binária não
 * balanceada.
 */
public class ArvoreBinaria {
    /**
     * Classe No
     * Função: Classe responsável por representar a estrutura de um nó presente
     * em uma árvore binária contendo um registro(Classe Item) e dois apontadores
     * do tipo No (esq, dir).
     */
    private static class No {
        Item reg;
        No esq, dir;
    }
    
    //Atributos da classe
    private No raiz;
    private long comparacoes;
    private int quantElementos;
    /**
     * Construtor ArvoreBinaria
     * Função: Inicializar a raiz e o atributo comparacoes
     */
    public ArvoreBinaria(){
        this.raiz = null;
        this.comparacoes = 0;
        this.quantElementos = 0;
    }
    
    /**
     * Método insere
     * @param reg
     * Função: realizar a chamada do método recursivo responsável por fazer
     * a inserção de um registro na árvore.
     */
    public void insere(Item reg){
        this.raiz = this.insere(reg, this.raiz);
    }
    
    /**
     * Método insere
     * @param reg
     * @param p
     * @return nó raiz
     * Função: realizar a inserção de um registro na árvore a partir de uma
     * execução recursiva para percorrer a mesma até que encontre um nó nulo.
     * Caso o elemento já exista, é retornado um erro informando a existência.
     */
    private No insere(Item reg, No p){
        if(p == null){
            p = new No(); 
            p.reg = reg;
            p.esq = null;
            p.dir = null;
            this.quantElementos++;
        } else if(reg.compara(p.reg) < 0){
            p.esq = insere(reg, p.esq);
        } else if (reg.compara(p.reg) > 0){
            p.dir = insere(reg, p.dir);
        } else {
            System.out.println("ERRO: Elemento já existente.");
        }
        
        return p;
    }
    
    /**
     * Método pesquisa
     * @param reg
     * @return resultado da pesquisa true ou false
     * Função: realizar a chamada do método recursivo responsável por fazer
     * a pesquisa de um registro na árvore. Caso a chamada retorne true, então
     * o elemento foi encontrado e se retornar false o elemento não foi encontrado.
     */
    public boolean pesquisa(Item reg){
        return (this.pesquisa(reg, this.raiz) != null);
    }
    
    /**
     * Método pesquisa
     * @param reg
     * @param p
     * @return registro pesquisado podendo ser o próprio registro ou null
     * Função: realizar a pesquisa de um registro na árvore a partir de uma
     * execução recursiva para percorrer a mesma até que encontre o elemento
     * pesquisado ou um nulo.
     */
    private Item pesquisa(Item reg, No p){
        if(p == null){
            this.comparacoes = this.comparacoes + 1;
            return null;
        } else if(reg.compara(p.reg) < 0){
            this.comparacoes = this.comparacoes + 1;
            return pesquisa(reg, p.esq);
        } else if(reg.compara(p.reg) > 0){
            this.comparacoes = this.comparacoes + 1;
            return pesquisa(reg, p.dir);
        } else {
            return p.reg;
        }
    }
    
    /**
     * Método getComparações
     * @return o número de comparações para as operações realizadas
     * Função: retornar o número de comparações obtidas para determinada operação
     * na árvore.
     */
    public long getComparacoes(){
        return this.comparacoes;
    }
    /**
     * Método getQuantElementos
     * @return a quantidade de elementos presente na árvore
     * Função: retornar o número corresponde a quantidade de elementos presente
     * na árvore
     */
    public int getQuantElementos(){
        return this.quantElementos;
    }
}
