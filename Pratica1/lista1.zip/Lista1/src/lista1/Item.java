/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lista1;
//Classe Item
public class Item {

    private int chave;
    
    /**
     * Classe Item
     * @param chave
     * Função: Construtor, inicializar atributos
     */
    public Item(int chave) {
        this.chave = chave;
    }
    
    /**
     * Método compara
     * @param it
     * @return -1 caso chave seja menor do que a fornecida e 1 caso seja maior.
     * Sendo iguais é retornado o valor 0.
     */
    public int compara(Item it) {
        Item item = it;
        if (this.chave < item.chave) {
            return -1;
        } else if (this.chave > item.chave) {
            return 1;
        }
        return 0;
    }
    
    /**
     * Método getChave
     * @return o valor correspondente do atributo chave
     */
    public int getChave() {
        return chave;
    }
}
