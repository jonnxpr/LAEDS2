package caixeiroViajante;

/**
 *
 * @author Jonathan Douglas Diego Tavares
 * @matricula 201622040228
 * @disciplina Laboratório de Algoritmos e Estrutura de Dados II
 */
public class Main {
    
    public static double getRandomDoubleBetweenRange(double min, double max){
        double x = (Math.random()*((max-min)+1))+min;
        return x;
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int cidadeInicial = 0;
        Guloso guloso;
        ForcaBruta forcaBruta;
        Grafo grafo = new Grafo(10000);
        Problema problema;
        long tempoInicial;
        
        for (int i = 0; i < grafo.numeroVertices; i++){
            for (int j = i + 1; j < grafo.numeroVertices; j++){
                grafo.insereArestaNaoOrientada(i, j, (int)Main.getRandomDoubleBetweenRange(0, 500));
            }
        }
        
        //Solução: 12
        //grafo.insereArestaNaoOrientada(0, 1, 5);
        //grafo.insereArestaNaoOrientada(0, 2, 1);
        //grafo.insereArestaNaoOrientada(0, 3, 2);
        //grafo.insereArestaNaoOrientada(1, 2, 3);
        //grafo.insereArestaNaoOrientada(2, 3, 4);
        //grafo.insereArestaNaoOrientada(3, 1, 6);

        
        problema = new Problema(grafo);
        guloso = new Guloso(problema);
        forcaBruta = new ForcaBruta(problema);
        
        tempoInicial = System.currentTimeMillis();
        Solucao solucao = guloso.getSolucao(cidadeInicial);
        System.out.println("Solução: " + solucao.getDistanciaTotal());
        
        //solucao = forcaBruta.getSolucao(cidadeInicial);
        //System.out.println("Solução: " + solucao.getDistanciaTotal());
        
        long tempoFinal = System.currentTimeMillis();
        System.out.printf("Tempo total de execução: %.3f ms%n", (tempoFinal - tempoInicial) / 1000d);
    } 
}
