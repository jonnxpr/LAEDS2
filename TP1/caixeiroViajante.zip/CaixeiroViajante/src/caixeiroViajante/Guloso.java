/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package caixeiroViajante;

import java.util.ArrayList;

/**
 *
 * @author Jonathan
 */
public class Guloso {
    private final Problema problema;
    private final Solucao solucao;
    
    public Guloso(Problema problema){
        this.problema = problema;
        solucao = new Solucao();
    }
    
    private int getVerticeComArestaDeMenorPeso(int cidadeAtual, ArrayList<Integer> lista){
        int verticeEscolhido = lista.get(0);
        
        for (int i = 1; i < lista.size(); i++){
            if (problema.getDistancia(cidadeAtual, lista.get(i)) < problema.getDistancia(cidadeAtual, verticeEscolhido)){
                verticeEscolhido = lista.get(i);
            }
        }
        return verticeEscolhido;
    }
    
    private void calculaMenorCaminho(int cidadeInicial){
        ArrayList<Integer> caminhoTemp = new ArrayList<>();
        caminhoTemp.add(cidadeInicial);
        int cidadeAtual = cidadeInicial;
        int cidadeMaisProxima;
        int distanciaTotal = 0;
        int verticeDeMenorAresta;
        int nCidades =  problema.getGrafo().numVertices();
        
        while (caminhoTemp.size() < nCidades){
            ArrayList<Integer> listaAdj = problema.getGrafo().listaDeAdjacencia(cidadeAtual);
            
            for (Integer i : caminhoTemp){
                listaAdj.remove(i);
            }
            
            verticeDeMenorAresta = getVerticeComArestaDeMenorPeso(cidadeAtual, listaAdj);
            cidadeMaisProxima = verticeDeMenorAresta;
            //System.out.println("DistanciaEscolhida: " + problema.getDistancia(cidadeAtual, cidadeMaisProxima));
            distanciaTotal = distanciaTotal + problema.getDistancia(cidadeAtual, cidadeMaisProxima);
            
            caminhoTemp.add(cidadeMaisProxima);
            
            cidadeAtual = cidadeMaisProxima;
        }
        
        distanciaTotal = distanciaTotal + problema.getDistancia(cidadeAtual, caminhoTemp.get(0));
        caminhoTemp.add(cidadeInicial);
        
        solucao.setCaminho(caminhoTemp);
        //solucao.mostrarCaminho();
        solucao.setDistanciaTotal(distanciaTotal);
    }
    
    public Solucao getSolucao(int cidadeInicial){
        calculaMenorCaminho(cidadeInicial);
        return solucao;
    }
}
