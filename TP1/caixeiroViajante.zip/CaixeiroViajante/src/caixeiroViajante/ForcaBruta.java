/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package caixeiroViajante;

import java.util.ArrayList;

/**
 *
 * @author Jonathan
 */
public class ForcaBruta {
    private final Problema problema;
    private final Solucao solucao;
    ArrayList<int[]> caminhos;
    Permutacoes permutacoes;
    
    
    public ForcaBruta(Problema problema){
        this.problema = problema;
        solucao = new Solucao();
        caminhos = new ArrayList<>();
        permutacoes = new Permutacoes();
    }
    
    private int[] geraPermutacaoInicial(int cidadeInicial){
        int permutacao[] = new int[problema.getGrafo().numVertices()-1];
        int i = 0;
        int pos = 0;
        
        while(i < permutacao.length+1){
            if (i != cidadeInicial){
                permutacao[pos] = i;
                pos++;
                i++;
            } else {
                i++;
            }
        }
        
        return permutacao;
    }
    
    private ArrayList<int[]> completarCaminhos(int cidadeInicial, ArrayList<int[]> array){
        ArrayList<int[]> caminhosCompletos = new ArrayList<>();
        for (int i = 0; i < array.size(); i++){
            int aux[] = new int[problema.getGrafo().numVertices()+1];
            aux[0] = cidadeInicial;
            aux[aux.length-1] = cidadeInicial;
            
            for (int j = 1; j < array.get(i).length+1; j++){
                aux[j] = array.get(i)[j-1];
            }
            
            caminhosCompletos.add(aux);
        }
        
        return caminhosCompletos;
    }
    
    private int getDistanciaCaminho(int[] caminho){ 
        int distancia = 0;
        
        for (int i = 0; i < caminho.length-1; i++){
            distancia = distancia + problema.getDistancia(caminho[i], caminho[i+1]);
        }
        
        return distancia;
    }
    
    private void calculaMenorCaminho(int cidadeInicial){
        caminhos = permutacoes.getPermutacoes(geraPermutacaoInicial(cidadeInicial));
        //imprime(caminhos);
        ArrayList<int[]> caminhosCompletos = completarCaminhos(cidadeInicial, caminhos);
        int menorCaminho[] = caminhosCompletos.get(0);
        ArrayList<Integer> menorCaminhoList = new ArrayList<>();
        //imprime(caminhosCompletos);
        
        for (int i = 1; i < caminhosCompletos.size(); i++){
            if (getDistanciaCaminho(caminhosCompletos.get(i)) < getDistanciaCaminho(menorCaminho)){
                menorCaminho = caminhosCompletos.get(i);
            }
        }
        
        for (int i = 0; i < menorCaminho.length; i++){
            menorCaminhoList.add(menorCaminho[i]);
        }
        
        solucao.setCaminho(menorCaminhoList);
        //solucao.mostrarCaminho();
        solucao.setDistanciaTotal(getDistanciaCaminho(menorCaminho));
    }
    
    private void imprime(ArrayList<int[]> arrayList) {
        for (int i = 0; i < arrayList.size(); i++){
            for (int j = 0; j < arrayList.get(i).length; j++){
                System.out.print(arrayList.get(i)[j] + " ");
            }
            System.out.println("");
        }
    }
    
    public Solucao getSolucao(int cidadeInicial){
        calculaMenorCaminho(cidadeInicial);
        return solucao;
    }
}
