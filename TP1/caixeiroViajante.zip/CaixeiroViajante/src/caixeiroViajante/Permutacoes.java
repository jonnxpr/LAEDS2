package caixeiroViajante;

import java.util.ArrayList;

/**
 * Esta classe gera e imprime as diferentes permutações de n objetos
 *
 */
 
public class Permutacoes {     
    private int permutacaoAtual[];

    private ArrayList<int[]> permutacoes;
     
    public void permuta(int [] vet) {
        permutacoes = new ArrayList<>();
        permutacaoAtual = new int[vet.length];
        permuta(vet,0);
    }
             
    private void permuta(int []vet, int n) {
        
        if (n==vet.length) {
            imprime();
        } else {
                     
            for (int i=0; i < vet.length; i++) {
             
                boolean achou = false;
             
                for (int j = 0; j < n; j++) {
                 
                    if (permutacaoAtual[j]==vet[i]) achou = true;
                }
             
                if (!achou) {
                     
                    permutacaoAtual[n] = vet[i];
                    
                    permuta(vet,n+1);
                }
                 
            }
             
        }   
    }

    /** imprime a permutacao corrente */
    private void imprime() {
        int aux[] = new int[permutacaoAtual.length];
        //System.out.println();
        //System.out.print("(" + cont + ") : ");
        for (int i=0; i < permutacaoAtual.length; i++){
            //System.out.print(p[i] + " ");
            aux[i] = permutacaoAtual[i];
        }
        
        permutacoes.add(aux);
    }
    
    public ArrayList<int[]> getPermutacoes(int[] vetor){
        permuta(vetor);
        return permutacoes;
    }     
}
