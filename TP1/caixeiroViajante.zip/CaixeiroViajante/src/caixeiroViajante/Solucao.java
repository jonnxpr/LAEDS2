/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package caixeiroViajante;

import java.util.ArrayList;

/**
 *
 * @author Jonathan
 */
public class Solucao {

    private int distanciaTotal;
    private ArrayList<Integer> caminho;

    public Solucao() {
        this.distanciaTotal = 0;
        caminho = new ArrayList<>();
    }
    
    public void incrementarDistanciaTotal(int distancia){
        distanciaTotal = distanciaTotal + distancia;
    }
    

    public void addCidadeNoCaminho(int cidade) {
        caminho.add(cidade);
    }
    
    public int getDistanciaTotal(){
        return distanciaTotal;
    }

    public ArrayList<Integer> getCaminho() {
        return (ArrayList<Integer>) caminho.clone();
    }
    
    public int getUltimaCidade(){
        return caminho.get(caminho.size()-1);
    }
    
    public int getQuantCidadesNoCaminho(){
        return caminho.size();
    }
    
    public void mostrarCaminho(){
        System.out.println("Caminho:");
        for (Integer i : caminho){
            System.out.print(i + " ");
        }
        System.out.println("");
    }
    
    public void setCaminho(ArrayList<Integer> caminho){
        this.caminho = caminho;
    }
    
    public void setDistanciaTotal(int distancia){
        distanciaTotal = distancia;
    }
}
