
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author aluno
 */
public class Main {
        
    public int calculaLucro(int quantDias, ArrayList<Integer> custos){ 
        if (quantDias == 0){
            return 0;
        }
        
        
        
        int lucroMax = 0;
        int lucroLocal = custos.get(0);
        
        for (int i = 0; i < quantDias; i++){
  
        }
        
        
        return lucroMax;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Main main = new Main();
        Scanner in = new Scanner(System.in);
        ArrayList<Integer> custos;
        int quantDias;
        int custoPorDia;
        
        while(in.hasNext()){
            quantDias = Integer.parseInt(in.nextLine());
            custoPorDia = Integer.parseInt(in.nextLine());
            custos = new ArrayList<>();
            
            for (int i = 0; i < quantDias; i++){
                custos.add(Integer.parseInt(in.nextLine()));
            }
            
            System.out.println(main.calculaLucro(quantDias, custos));
            
        }   
    }
    
}
